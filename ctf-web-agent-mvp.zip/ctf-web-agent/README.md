# Local CTF Web Agent MVP

本地优先的 Python CTF Web 分析 Agent。支持读取本地题目源码、对 localhost 做少量 GET 请求、整理证据并输出 JSON 报告；可选接入 OpenAI API 总结证据和建议下一步。

## 功能
- 扫描题目源码目录，列出文件、SHA-256、相关代码行和有限源码片段。
- 本机 Web 靶场 GET-only 检查：首页响应头、表单、同源链接、少量链接页面、robots.txt、sitemap.xml。
- 生成 `ctf-web-report.json`，包含证据、观察结果和后续建议。
- 可选 LLM 分析。模型不会执行命令或自动调用工具。
- 不运行 shell 命令、不提交表单、不爆破、不自动发送漏洞利用载荷。

## 环境与安装
需要 Python 3.10+。
```bash
cd ctf-web-agent
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```
不使用 LLM 时可直接加 `--no-llm`，无需安装额外依赖。

## 分析源码
```bash
python ctf_web_agent.py --source ./challenge-source --no-llm
```

## 检查本地靶场
先启动自己有权测试的本地 CTF 服务：
```bash
python ctf_web_agent.py --url http://127.0.0.1:8080/ --no-llm
```

## 同时分析源码与运行服务
```bash
python ctf_web_agent.py --source ./challenge-source --url http://127.0.0.1:8080/
```

## 可选 LLM
设置环境变量，不要把密钥写进源码：
```bash
# Linux/macOS
export OPENAI_API_KEY="your-key"
export CTF_AGENT_MODEL="gpt-4.1-mini"
# Windows PowerShell
# $env:OPENAI_API_KEY="your-key"
# $env:CTF_AGENT_MODEL="gpt-4.1-mini"
```
安装 SDK：`python -m pip install -r requirements.txt`，再运行时不加 `--no-llm`。
注意：发送源码给云端模型前应检查敏感信息。程序排除了 `.env` 并尝试对常见凭据赋值行脱敏，但不能保证识别所有秘密。

## 限制
这是可运行的 MVP，不是自动漏洞利用器。目标检查仅允许 localhost/loopback。后续如加入主动测试，应实现明确目标白名单、请求预算、速率限制、人工确认、隔离执行和审计日志。

仅用于你拥有或明确获准测试的 CTF 环境。
