#!/usr/bin/env python3
"""Local CTF Web Agent MVP for authorized, local CTF analysis."""
from __future__ import annotations
import argparse, hashlib, json, os, re, socket, time, urllib.error, urllib.parse, urllib.request
from dataclasses import asdict, dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

MAX_FILE = 2 * 1024 * 1024
MAX_BODY = 512 * 1024
UA = "Local-CTF-Web-Agent/0.1"

@dataclass
class Evidence:
    kind: str
    source: str
    detail: str
    confidence: str = "observed"

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.scripts, self.forms = [], [], []
        self._form = None
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "a" and a.get("href"): self.links.append(a["href"])
        if tag == "script" and a.get("src"): self.scripts.append(a["src"])
        if tag == "form":
            self._form = {"action": a.get("action", ""), "method": a.get("method", "GET").upper(), "inputs": []}
            self.forms.append(self._form)
        elif tag in ("input", "textarea", "select", "button") and self._form is not None:
            self._form["inputs"].append({"tag": tag, "name": a.get("name", ""), "type": a.get("type", tag), "id": a.get("id", "")})
    def handle_endtag(self, tag):
        if tag == "form": self._form = None

def validate_local_url(url: str) -> str:
    p = urllib.parse.urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Target must be an absolute http(s) URL.")
    host = p.hostname.lower()
    if host == "localhost": return url
    try:
        addresses = socket.getaddrinfo(host, p.port or (443 if p.scheme == "https" else 80))
    except socket.gaierror as e:
        raise ValueError(f"Cannot resolve host: {host}") from e
    if not addresses or any(not x[4][0].startswith(("127.", "::1")) for x in addresses):
        raise ValueError("Safety guard: this MVP only sends requests to localhost/loopback targets.")
    return url

def get_url(url: str, timeout: int = 4) -> dict[str, Any]:
    validate_local_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read(MAX_BODY + 1)
            truncated = len(body) > MAX_BODY
            body = body[:MAX_BODY]
            return {"url": r.geturl(), "status": r.status, "headers": dict(r.headers.items()),
                    "body": body.decode("utf-8", errors="replace"), "truncated": truncated}
    except urllib.error.HTTPError as e:
        return {"url": url, "status": e.code, "headers": dict(e.headers.items()),
                "body": e.read(MAX_BODY).decode("utf-8", errors="replace")}
    except Exception as e:
        return {"url": url, "error": f"{type(e).__name__}: {e}"}

def inspect_target(base_url: str) -> dict[str, Any]:
    base_url = base_url.rstrip("/") + "/"
    home = get_url(base_url)
    if "error" in home: return {"target": base_url, "error": home["error"]}
    parser = PageParser(); parser.feed(home.get("body", ""))
    origin = urllib.parse.urlparse(base_url)
    same_origin = []
    for item in parser.links + parser.scripts:
        full = urllib.parse.urljoin(base_url, item); p = urllib.parse.urlparse(full)
        if p.scheme in ("http", "https") and p.netloc == origin.netloc and full not in same_origin:
            same_origin.append(full)
    common = {}
    for path in ("robots.txt", "sitemap.xml"):
        result = get_url(urllib.parse.urljoin(base_url, path))
        common[path] = {k:v for k,v in result.items() if k != "body"}
        if "body" in result: common[path]["body_sample"] = result["body"][:2000]
    linked = {}
    for url in same_origin[:8]:
        if url == home.get("url"): continue
        result = get_url(url)
        linked[url] = {k:v for k,v in result.items() if k != "body"}
        if "body" in result: linked[url]["body_sample"] = result["body"][:2500]
    return {"target": base_url, "homepage": {k:v for k,v in home.items() if k != "body"},
            "homepage_body_sample": home.get("body", "")[:10000], "same_origin_links": same_origin[:40],
            "forms": parser.forms[:25], "scripts": parser.scripts[:25], "common_paths": common,
            "linked_pages": linked, "scope": "GET-only localhost inspection; no form submissions or exploit payloads."}

def read_source_tree(root: Path) -> dict[str, Any]:
    if not root.exists() or not root.is_dir(): raise ValueError(f"Source directory not found: {root}")
    records = []
    extensions = {".py",".php",".js",".ts",".html",".htm",".txt",".json",".yaml",".yml",".ini",".conf"}
    pattern = r"route|render|template|query|select|execute|cursor|request|cookie|session|upload|file|include|eval|exec|deserialize|pickle|jwt|secret|debug|password|token|flag|sql|shell|subprocess"
    for path in sorted(root.rglob("*")):
        if not path.is_file(): continue
        try:
            rel = path.relative_to(root)
            if any(part in {".git",".venv","node_modules","__pycache__","venv"} for part in rel.parts): continue
            size = path.stat().st_size
            if size > MAX_FILE:
                records.append({"path": str(rel), "size": size, "skipped": "file exceeds 2 MiB"}); continue
            raw = path.read_bytes()
            rec = {"path": str(rel), "size": size, "sha256": hashlib.sha256(raw).hexdigest()}
            try: content = raw.decode("utf-8")
            except UnicodeDecodeError: content = ""
            if content and (path.suffix.lower() in extensions or path.name.lower() in {"dockerfile","requirements.txt","package.json","composer.json"}):
                rec["text_sample"] = content[:7000]
                rec["interesting_lines"] = [{"line":i+1,"text":line[:300]} for i,line in enumerate(content.splitlines()) if re.search(pattern,line,re.I)][:80]
            records.append(rec)
        except OSError as e: records.append({"path":str(path),"error":str(e)})
        if len(records) >= 250: break
    return {"source_root":str(root.resolve()),"files":records,"file_count":len(records)}

def build_evidence(target, source):
    ev = []
    if target:
        if target.get("error"): ev.append(Evidence("error","target",target["error"]))
        else:
            h = target.get("homepage",{})
            ev.append(Evidence("http",target.get("target",""),f"status={h.get('status')}; url={h.get('url')}"))
            headers = h.get("headers",{})
            for key in ("Server","X-Powered-By","Set-Cookie","Content-Security-Policy"):
                if key in headers: ev.append(Evidence("header",key,str(headers[key])[:300]))
            for form in target.get("forms",[]): ev.append(Evidence("form",form.get("action","/"),json.dumps(form,ensure_ascii=False)[:800]))
            for link in target.get("same_origin_links",[])[:25]: ev.append(Evidence("link",link,"same-origin link discovered"))
    if source:
        for f in source.get("files",[]):
            path=f.get("path","")
            if f.get("interesting_lines"): ev.append(Evidence("source",path,f"{len(f['interesting_lines'])} potentially relevant lines; inspect context before conclusions"))
            if re.search(r"\.(env|bak|old|sql|zip|tar|gz)$",path,re.I): ev.append(Evidence("file",path,"backup-like filename; low-confidence lead","low"))
    return ev

def llm_summary(evidence, source):
    if not os.getenv("OPENAI_API_KEY"): return None
    try:
        from openai import OpenAI
        safe_files=[]
        if source:
            for f in source.get("files",[]):
                if Path(f.get("path","")).name.lower()==".env": continue
                sample=f.get("text_sample")
                if sample:
                    sample=re.sub(r"(?im)^(\s*(?:api[_-]?key|secret|password|token)\s*[:=]\s*).+$",r"\1[REDACTED]",sample)
                    safe_files.append({"path":f["path"],"text_sample":sample[:2500]})
        payload={"evidence":[asdict(x) for x in evidence][:100],"source_files":safe_files[:12]}
        prompt=("Analyze this authorized local CTF Web challenge evidence. Separate observations, hypotheses, "
                "and unknowns. Give prioritized next steps. Do not claim a vulnerability without evidence; "
                "do not execute tools or invent results. Avoid repeating secrets.\n"+
                json.dumps(payload,ensure_ascii=False)[:18000])
        result=OpenAI().responses.create(model=os.getenv("CTF_AGENT_MODEL","gpt-4.1-mini"),input=prompt)
        return result.output_text
    except Exception as e: return f"LLM summary unavailable: {type(e).__name__}: {e}"

def main():
    p=argparse.ArgumentParser(description="Local CTF Web Agent MVP")
    p.add_argument("--url",help="Local challenge URL, e.g. http://127.0.0.1:8080/")
    p.add_argument("--source",type=Path,help="Challenge source directory")
    p.add_argument("--output",type=Path,default=Path("ctf-web-report.json"))
    p.add_argument("--no-llm",action="store_true")
    args=p.parse_args()
    if not args.url and not args.source: p.error("Provide --url and/or --source")
    target=inspect_target(args.url) if args.url else None
    source=read_source_tree(args.source.resolve()) if args.source else None
    evidence=build_evidence(target,source)
    result={"agent":"Local-CTF-Web-Agent","created_unix":int(time.time()),"target_report":target,
            "source_report":source,"evidence":[asdict(x) for x in evidence],
            "next_steps":["建立路由、输入点、身份验证和文件处理清单。","阅读相关源码上下文，追踪用户输入到敏感操作的数据流。",
                          "为每个假设设计最小、可重复的验证步骤；只在获准的本地靶场测试。"],
            "safety":"GET-only localhost inspection; no form submissions, brute force, exploit payloads, or shell execution."}
    if not args.no_llm:
        summary=llm_summary(evidence,source)
        if summary: result["llm_summary"]=summary
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"report":str(args.output.resolve()),"evidence_count":len(evidence),
                      "source_files":source.get("file_count") if source else 0,
                      "target_checked":bool(target),"llm_enabled":bool(result.get("llm_summary")),
                      "next_steps":result["next_steps"]},ensure_ascii=False,indent=2))
    if result.get("llm_summary"): print("\n=== LLM Analysis ===\n"+result["llm_summary"])

if __name__=="__main__": main()
