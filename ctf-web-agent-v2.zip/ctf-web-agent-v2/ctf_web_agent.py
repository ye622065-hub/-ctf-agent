#!/usr/bin/env python3
"""CTF Web Agent v2: local-first passive inspection and evidence-linked heuristic review."""
from __future__ import annotations
import argparse, hashlib, html, json, os, re, socket, time, urllib.error, urllib.parse, urllib.request
from dataclasses import asdict, dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

VERSION = "2.0.0"
EXTS = {".py",".php",".js",".jsx",".ts",".tsx",".html",".htm",".json",".xml",".yml",".yaml",".ini",".conf",".txt",".md",".rb",".go",".java",".cs",".sql",".sh",".vue",".ejs",".jinja",".jinja2"}
SKIP = {".git",".svn",".hg",".venv","venv","node_modules","__pycache__","dist","build",".next","coverage","vendor"}
REDACT = "[REDACTED]"

@dataclass
class Finding:
    finding_id: str
    rule_id: str
    title: str
    severity: str
    confidence: str
    status: str
    source: str
    line: int | None
    evidence: str
    rationale: str
    verification: str

RULES = [
 ("WEB001","Possible SQL query/input concatenation","high","medium",{".py",".php",".js",".ts",".java",".rb",".go",".sql"},
  re.compile(r"(?i)(execute|query|raw|cursor\.execute)\s*\(.*(%s|\?|\+\s*(request|req\.|params|input|user|query))"),
  "A database call appears near interpolation or request-derived input.",
  "Trace the input into the query sink and confirm parameterized queries are used."),
 ("WEB002","Possible server-side template injection sink","high","low",{".py",".php",".js",".ts",".rb"},
  re.compile(r"(?i)(render_template_string|from_string|Template\s*\(|ejs\.render)\s*\("),
  "A dynamic template API appears in source; attacker control of the template source is not established.",
  "Trace the template string origin and distinguish template source from ordinary template variables."),
 ("WEB003","Possible unsafe file path","medium","low",{".py",".php",".js",".ts",".java",".rb",".go"},
  re.compile(r"(?i)(open\s*\(|readFile(?:Sync)?\s*\(|file_get_contents\s*\(|send_file\s*\().*(request|req\.|params|query|filename|filepath|path)"),
  "A file access operation appears near a request/path-related value.",
  "Check path normalization, directory boundaries, and authorization."),
 ("WEB004","Possible unsafe command execution","high","low",{".py",".php",".js",".ts",".java",".rb",".go",".sh"},
  re.compile(r"(?i)(os\.system|subprocess\.(?:run|Popen|call)|child_process\.exec|shell_exec|system\s*\().*(request|req\.|params|query|input|user)"),
  "A command execution API appears near request/user-derived data.",
  "Trace whether untrusted data reaches the command. This agent does not execute commands."),
 ("WEB005","Possible unsafe HTML rendering / XSS","medium","low",{".py",".php",".js",".ts",".html",".ejs",".jinja",".jinja2"},
  re.compile(r"(?i)(innerHTML\s*=|dangerouslySetInnerHTML|mark_safe\s*\(|\|safe\b|v-html\s*=|document\.write\s*\()"),
  "A construct that can bypass normal output escaping appears in source.",
  "Trace the value origin and confirm context-appropriate escaping or sanitization."),
 ("WEB006","Possible hard-coded credential","medium","low",{".py",".php",".js",".ts",".json",".yml",".yaml",".ini",".conf"},
  re.compile(r"(?i)\b(password|passwd|secret|api[_-]?key|token)\b\s*[:=]\s*[\x22\x27][^\x22\x27]{4,}[\x22\x27]"),
  "A credential-like assignment appears in source; value is redacted in evidence.",
  "Check whether it is a real secret or a placeholder. Do not include secrets in reports."),
 ("WEB007","Possible insecure deserialization","high","low",{".py",".php",".js",".ts",".java",".rb"},
  re.compile(r"(?i)(pickle\.loads?|yaml\.load\s*\(|unserialize\s*\(|ObjectInputStream)"),
  "A security-sensitive deserialization API appears in source.",
  "Check whether serialized data is attacker-controlled and whether safe loaders or integrity checks are used."),
 ("WEB008","Sensitive route / authorization review lead","info","low",{".py",".php",".js",".ts",".java",".rb",".go"},
  re.compile(r"(?i)(@app\.route|router\.(get|post|put|delete|patch)|app\.(get|post|put|delete|patch)|def\s+\w*(admin|profile|account|download|upload)\w*\s*\()"),
  "A route/handler worth reviewing was found; this does not prove authorization is missing.",
  "Inspect route middleware and handler-level role and object authorization checks."),
]
SECRET_LINE = re.compile(r"(?i)(password|passwd|secret|api[_-]?key|token)(\s*[:=]\s*)([\x22\x27]).*?\3")

def redact(line: str) -> str:
    line = SECRET_LINE.sub(lambda m: m.group(1) + m.group(2) + m.group(3) + REDACT + m.group(3), line)
    if "BEGIN PRIVATE KEY" in line:
        return "[PRIVATE KEY MATERIAL REDACTED]"
    return line

def scan_source(root: Path, max_files: int = 500, max_bytes: int = 2_000_000):
    files, findings, notes = [], [], []
    count = 0
    for path in root.rglob("*"):
        if any(part in SKIP for part in path.parts) or not path.is_file() or path.suffix.lower() not in EXTS:
            continue
        count += 1
        if count > max_files:
            notes.append(f"Stopped at file limit ({max_files}).")
            break
        try:
            raw = path.read_bytes()
            if len(raw) > max_bytes:
                notes.append(f"Skipped large file: {path.relative_to(root)}")
                continue
            content = raw.decode("utf-8", errors="replace")
            lines = content.splitlines()
            rel = str(path.relative_to(root))
            files.append({"path": rel, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "line_count": len(lines)})
            for i, line in enumerate(lines, 1):
                for rid, title, sev, conf, exts, pattern, why, verify in RULES:
                    if path.suffix.lower() in exts and pattern.search(line):
                        findings.append(Finding(f"{rid}-{len(findings)+1:04d}", rid, title, sev, conf, "needs_review", rel, i, redact(line.strip())[:400], why, verify))
        except OSError as exc:
            notes.append(f"Could not read {path}: {type(exc).__name__}")
    return files, findings, notes

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links, self.scripts, self.forms, self.inputs = [], [], [], []
        self.form = None
    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k,v in attrs}
        if tag == "a" and a.get("href"): self.links.append(a["href"])
        if tag == "script" and a.get("src"): self.scripts.append(a["src"])
        if tag == "form":
            self.form = {"action": a.get("action",""), "method": a.get("method","get").upper(), "inputs":[]}
            self.forms.append(self.form)
        if tag in {"input","textarea","select","button"}:
            item = {"tag":tag,"type":a.get("type",""),"name":a.get("name",""),"id":a.get("id","")}
            self.inputs.append(item)
            if self.form is not None: self.form["inputs"].append(item)
    def handle_endtag(self, tag):
        if tag == "form": self.form = None

def loopback(host: str) -> bool:
    if host.lower() == "localhost": return True
    try:
        ips = {x[4][0] for x in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)}
        return bool(ips) and all(ip.startswith("127.") or ip == "::1" for ip in ips)
    except OSError: return False

def validate_url(url: str) -> str:
    p = urllib.parse.urlparse(url)
    if p.scheme not in {"http","https"} or not p.hostname: raise ValueError("Provide an absolute http(s) URL.")
    if not loopback(p.hostname): raise ValueError("HTTP inspection is restricted to localhost / loopback addresses.")
    return url

def fetch(url: str, timeout=4, max_bytes=750_000):
    validate_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": f"CTF-Web-Agent/{VERSION} passive-inspector"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read(max_bytes+1); truncated = len(raw)>max_bytes; raw=raw[:max_bytes]
            body = raw.decode(r.headers.get_content_charset() or "utf-8", errors="replace")
            return {"url":r.geturl(),"status":r.status,"headers":dict(r.headers.items()),"content_type":r.headers.get("Content-Type",""),"body":body,"truncated":truncated,"error":None}
    except urllib.error.HTTPError as e:
        return {"url":url,"status":e.code,"headers":dict(e.headers.items()),"content_type":e.headers.get("Content-Type",""),"body":e.read(max_bytes).decode("utf-8",errors="replace"),"truncated":False,"error":f"HTTP {e.code}"}
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        return {"url":url,"status":None,"headers":{},"content_type":"","body":"","truncated":False,"error":f"{type(e).__name__}: {e}"}

def inspect_site(start: str, max_pages=8):
    validate_url(start)
    origin = urllib.parse.urlparse(start)
    queue, seen, pages, findings, notes = [start], set(), [], [], []
    while queue and len(pages) < max_pages:
        url = queue.pop(0); p = urllib.parse.urlparse(url)
        url = urllib.parse.urlunparse((p.scheme,p.netloc,p.path or "/",p.params,p.query,""))
        if url in seen: continue
        seen.add(url); r = fetch(url); body = r["body"]
        parser = PageParser()
        if "html" in r["content_type"].lower() or "<html" in body[:1000].lower():
            try: parser.feed(body)
            except Exception: pass
        pages.append({k:v for k,v in r.items() if k!="body"} | {
            "links":parser.links[:80],"scripts":parser.scripts[:80],"forms":parser.forms[:40],
            "inputs":parser.inputs[:80],"body_excerpt":html.escape(body[:600])})
        headers = {k.lower():v for k,v in r["headers"].items()}
        for key,label in [("content-security-policy","Content-Security-Policy"),("x-content-type-options","X-Content-Type-Options"),("x-frame-options","X-Frame-Options"),("referrer-policy","Referrer-Policy")]:
            if r["status"] and key not in headers:
                findings.append(Finding(f"HTTP-{len(findings)+1:04d}","HTTP001",f"Missing {label} header","info","high","observed",url,None,f"Missing header: {label}","Hardening observation, not proof of an exploitable vulnerability.","Review whether this header is appropriate for the app and deployment."))
        for link in parser.links + parser.scripts:
            absolute = urllib.parse.urljoin(url,link); lp = urllib.parse.urlparse(absolute)
            if lp.scheme in {"http","https"} and lp.netloc == origin.netloc and loopback(lp.hostname or "") and absolute not in seen and len(queue)<max_pages*3:
                queue.append(absolute)
    if queue: notes.append(f"Page limit reached ({max_pages}); remaining links were not inspected.")
    return pages, findings, notes

def make_summary(files, findings, pages):
    rank={"critical":0,"high":1,"medium":2,"low":3,"info":4}
    ordered=sorted(findings,key=lambda f:(rank.get(f.severity,9),f.source,f.line or 0))
    steps=[]
    for rid,step in [
        ("WEB001","追踪数据库查询的输入来源，确认是否使用参数化查询。"),
        ("WEB002","确认动态模板字符串是否可被用户控制。"),
        ("WEB003","检查文件路径规范化、目录边界和权限校验。"),
        ("WEB005","检查危险 HTML 渲染点的输入来源与上下文编码。"),
        ("WEB008","逐条核对敏感路由的认证、角色和对象级授权。")]:
        if any(f.rule_id==rid for f in findings): steps.append(step)
    if not steps: steps.append("从入口路由、输入源、校验/变换到敏感操作建立数据流；未命中规则不代表没有漏洞。")
    counts={}
    for f in findings: counts[f.rule_id]=counts.get(f.rule_id,0)+1
    return {"files_scanned":len(files),"pages_inspected":len(pages),"finding_count":len(findings),"finding_counts_by_rule":counts,
      "priority_findings":[asdict(f) for f in ordered[:15]],"next_steps":steps,
      "limitations":["规则命中是审计线索，不等于漏洞已证实。","仅做静态启发式分析和被动 GET 检查；不提交表单、不爆破、不执行利用载荷。","不做完整跨函数数据流分析；复杂逻辑需要人工复核。"]}

def maybe_llm(report, model):
    key=os.getenv("OPENAI_API_KEY")
    if not key: return None
    try:
        from openai import OpenAI
    except ImportError:
        report["notes"].append("OPENAI_API_KEY exists but openai package is missing; skipped LLM review."); return None
    compact=[{"id":f["finding_id"],"rule":f["rule_id"],"title":f["title"],"severity":f["severity"],"source":f["source"],"line":f["line"],"evidence":f["evidence"],"verification":f["verification"]} for f in report["findings"][:30]]
    prompt="谨慎复核这些 CTF Web 审计线索。不要把线索说成已证实漏洞。返回 JSON：overall_assessment、highest_priority_checks、false_positive_warnings。不要提供破坏性操作或利用载荷。证据："+json.dumps(compact,ensure_ascii=False)
    try:
        res=OpenAI(api_key=key).chat.completions.create(model=model,messages=[{"role":"user","content":prompt}],response_format={"type":"json_object"},temperature=0.1)
        return json.loads(res.choices[0].message.content or "{}")
    except Exception as e:
        report["notes"].append(f"LLM review failed: {type(e).__name__}: {e}"); return None

def markdown(report):
    s=report["summary"]; out=[f"# CTF Web Agent Report v{VERSION}","",f"- Generated: {report['generated_at']}",f"- Files scanned: {s['files_scanned']}",f"- Pages inspected: {s['pages_inspected']}",f"- Findings: {s['finding_count']}","","## Findings",""]
    if not report["findings"]: out.append("No heuristic matches found. This is not a security guarantee.")
    for f in report["findings"]:
        loc=f["source"]+(f":{f['line']}" if f["line"] else "")
        out += [f"### [{f['severity'].upper()}] {f['title']}",f"- ID/rule: `{f['finding_id']}` / `{f['rule_id']}`",f"- Confidence/status: {f['confidence']} / {f['status']}",f"- Location: `{loc}`",f"- Evidence: `{f['evidence'].replace('`', chr(39))}`",f"- Rationale: {f['rationale']}",f"- Verify: {f['verification']}",""]
    out += ["## Next steps",""]+[f"{i}. {x}" for i,x in enumerate(s["next_steps"],1)]+["","## Limitations",""]+[f"- {x}" for x in s["limitations"]]
    if report["notes"]: out += ["","## Notes",""]+[f"- {n}" for n in report["notes"]]
    return "\n".join(out)+"\n"

def main():
    ap=argparse.ArgumentParser(description="Local-first CTF Web Agent v2")
    ap.add_argument("--source",type=Path,help="Challenge source directory")
    ap.add_argument("--url",help="Optional localhost challenge URL")
    ap.add_argument("--out",type=Path,default=Path("ctf-web-report.json"))
    ap.add_argument("--max-pages",type=int,default=8)
    ap.add_argument("--max-files",type=int,default=500)
    ap.add_argument("--no-llm",action="store_true")
    ap.add_argument("--model",default=os.getenv("CTF_AGENT_MODEL","gpt-4.1-mini"))
    a=ap.parse_args()
    if not a.source and not a.url: ap.error("Provide --source and/or --url.")
    if not 1<=a.max_pages<=20: ap.error("--max-pages must be 1..20.")
    if not 1<=a.max_files<=2000: ap.error("--max-files must be 1..2000.")
    files=[]; findings=[]; pages=[]; notes=[]
    if a.source:
        root=a.source.expanduser().resolve()
        if not root.is_dir(): ap.error(f"Not a directory: {root}")
        x,y,z=scan_source(root,a.max_files); files+=x; findings+=y; notes+=z
    if a.url:
        try:
            x,y,z=inspect_site(a.url,a.max_pages); pages+=x; findings+=y; notes+=z
        except ValueError as e: ap.error(str(e))
    report={"agent":"ctf-web-agent","version":VERSION,"generated_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
      "scope":{"source_directory":str(a.source.resolve()) if a.source else None,"start_url":a.url,"network_policy":"loopback-only","active_testing":False},
      "files":files,"pages":pages,"findings":[asdict(f) for f in findings],"notes":notes}
    report["summary"]=make_summary(files,findings,pages)
    if not a.no_llm:
        llm=maybe_llm(report,a.model)
        if llm: report["llm_review"]=llm
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=a.out.with_suffix(".md"); md.write_text(markdown(report),encoding="utf-8")
    print(f"[+] Files scanned: {len(files)} | Pages inspected: {len(pages)} | Findings: {len(findings)}")
    print(f"[+] JSON: {a.out}\n[+] Markdown: {md}")
    return 0

if __name__=="__main__": raise SystemExit(main())
