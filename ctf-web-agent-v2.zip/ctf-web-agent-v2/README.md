# CTF Web Agent v2

本地优先、证据驱动的 CTF Web 分析助手。扫描挑战源码，有限地检查本机 HTTP 页面，匹配常见风险线索，并生成 JSON 与 Markdown 报告。

## 功能
- 源码清点：文件大小、SHA-256、行数。
- 启发式规则：SQL 查询拼接、动态模板、文件路径、命令执行、危险 HTML 渲染、疑似硬编码凭据、不安全反序列化、敏感路由审查线索。
- 本机 HTTP 被动检查：响应头、页面链接、脚本、表单与输入字段。只发 GET，不提交表单。
- 每条发现关联规则 ID、文件/行号或 URL、证据、置信度、状态和复核建议。
- 输出 JSON + Markdown 报告。
- 可选 OpenAI 复核：只发送有限的发现摘要，不发送完整源文件。

## 安装 / 使用
Python 3.10+。纯本地模式不需要安装依赖：

```bash
python ctf_web_agent.py --source ./challenge-source --no-llm
python ctf_web_agent.py --url http://127.0.0.1:8080/ --no-llm
python ctf_web_agent.py --source ./challenge-source --url http://127.0.0.1:8080/ --out reports/analysis.json --no-llm
```

可选 LLM 复核：
```bash
python -m pip install -r requirements.txt
# Linux/macOS
export OPENAI_API_KEY="your-key"
# Windows PowerShell
$env:OPENAI_API_KEY="your-key"
python ctf_web_agent.py --source ./challenge-source
```

限制扫描范围：
```bash
python ctf_web_agent.py --source ./challenge-source --max-files 300 --max-pages 6 --no-llm
```

## 如何解读
- `needs_review` = 需要人工追踪数据流，不代表漏洞已确认。
- `observed` = 观察到的配置/响应现象。
- 缺少安全响应头只作为信息项，不直接定性为漏洞。
- 规则可能误报或漏报；未命中不代表安全。

## 安全边界与局限
只对自己拥有或明确获准测试的 CTF 环境使用。HTTP 目标限制为 localhost / loopback；只执行 GET，不提交表单、不爆破、不执行系统命令或利用载荷。当前版本不做完整跨函数数据流分析，也不会自动攻防解题。建议人工按“入口 → 输入源 → 校验/变换 → 敏感操作 → 权限边界”复核。
